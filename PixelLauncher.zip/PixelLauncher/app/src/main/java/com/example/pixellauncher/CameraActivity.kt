package com.example.pixellauncher

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

// Камера лаунчера (бета): зум и сохранение снимка в галерею
class CameraActivity : ComponentActivity() {
    private var cam: Camera? = null
    private var cap: ImageCapture? = null
    private lateinit var pv: PreviewView
    private lateinit var info: TextView
    private var maxZoom = 1f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PreviewView(this)
        root.addView(pv, -1, -1)
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER }
        root.addView(info, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(170) })
        val zoom = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                    val k = p / 100f
                    cam?.cameraControl?.setZoomRatio(1f + (maxZoom - 1f) * k * k)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(zoom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(32), 0, dp(32), dp(120)) })
        val shutter = View(this).apply {
            background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(Color.WHITE); setStroke(dp(5), 0x66FFFFFF) }
            setOnClickListener { shoot() }
        }
        root.addView(shutter, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(32) })
        setContentView(root)
        val need = if (Build.VERSION.SDK_INT <= 28) arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE) else arrayOf(Manifest.permission.CAMERA)
        if (need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) start()
        else ActivityCompat.requestPermissions(this, need, 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }) start()
        else { Toast.makeText(this, "Нужно разрешение на камеру", Toast.LENGTH_LONG).show(); finish() }
    }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            val prev = Preview.Builder().build()
            prev.setSurfaceProvider(pv.surfaceProvider)
            cap = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            p.unbindAll()
            cam = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, cap)
            cam?.cameraInfo?.zoomState?.observe(this) { z ->
                maxZoom = z.maxZoomRatio
                info.text = "Зум ×%.1f (максимум телефона ×%.0f)".format(z.zoomRatio, z.maxZoomRatio)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot() {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "PL_" + System.currentTimeMillis())
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PixelLauncher")
        }
        val o = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v).build()
        cap?.takePicture(o, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                Toast.makeText(this@CameraActivity, "Сохранено в галерею", Toast.LENGTH_SHORT).show()
            }
            override fun onError(e: ImageCaptureException) {
                Toast.makeText(this@CameraActivity, "Не удалось сохранить: " + e.message, Toast.LENGTH_LONG).show()
            }
        })
    }
}
